package otherClasses;

public class Order {

    @Override
    public String toString() {
        return "Order{}";
    }
}
