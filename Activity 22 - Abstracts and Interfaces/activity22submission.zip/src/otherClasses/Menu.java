package otherClasses;

public class Menu {

    @Override
    public String toString() {
        return "Menu{}";
    }
}
