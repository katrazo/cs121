package otherClasses;

public class Table {

    @Override
    public String toString() {
        return "Table{}";
    }
}
