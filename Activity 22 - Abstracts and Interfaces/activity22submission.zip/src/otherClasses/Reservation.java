package otherClasses;

public class Reservation {

    @Override
    public String toString() {
        return "Reservation{}";
    }
}
