package packagesDemo;

// This class uses a main() method to instantiate a NumberGuesser Object and test access to its methods.
public class Main {
    public static void main(String[] args) {
        NumberGuesser myGame = new NumberGuesser(10,"Haha! Try again!");

        // Public access
        myGame.guess(5);
        // Protected access
        myGame.showHint();
        myGame.guess(6);
        // Default Access
        myGame.showNumOfGuesses(); // 2
        // Private Access
        /* Throws compile-time error due to lack of access
         * myGame.giveAnswer();
         */

        String test = myGame.taunt; // works because myGame.taunt is public
        // String test2 = myGame.hint; // does not work because myGame.hint is private
        int test2 = myGame.numOfGuesses; // works because myGame.numOfGuesses is public
        // int test = myGame.numberToGuess; // does not work because myGame.numberToGuess is private
    }
}
