public class RecursionTest {
    public static void main(String[] args) {
        Recursion recursion = new Recursion();
        System.out.println();

        recursion.countDown(10);
        System.out.println();
        recursion.alphaBackwards('z');
    }
}
