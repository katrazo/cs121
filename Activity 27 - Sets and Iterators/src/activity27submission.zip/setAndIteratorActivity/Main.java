package setAndIteratorActivity;

public class Main {
    public static void main(String[] args) {
        RestaurantSet restaurant = new RestaurantSet();
        restaurant.addTables();
        restaurant.displayTables();
    }
}
